package com.control;

/**
 * Background producers. Both write to {@link SharedState} without synchronization.
 */
public final class Workers {

    private Workers() {
    }

    /**
     * Arm A: a single writer that takes a while to produce its result. The test
     * asserts on the value before this has necessarily run, which is the classic
     * asynchronous-wait shape FlakeSync targets. Because there is only one writer,
     * no update is lost -- ordering the test after this write is sufficient to make
     * the test correct, so a barrier is a genuine repair.
     */
    public static Thread producer(final SharedState state, final int workMillis) {
        return new Thread(new Runnable() {
            public void run() {
                try {
                    Thread.sleep(workMillis);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    return;
                }
                state.setValue(42);
                state.markReady();
            }
        }, "producer");
    }

    /**
     * Arm B: one of two threads doing an unsynchronized read-modify-write. Ordering
     * the test after both threads finish does not help, because the lost updates
     * happen between the two workers, not between a worker and the test.
     */
    public static Thread incrementer(final SharedState state, final int iterations,
                                     final String name) {
        return new Thread(new Runnable() {
            public void run() {
                for (int i = 0; i < iterations; i++) {
                    state.increment();
                }
            }
        }, name);
    }
}
