package com.control;

/**
 * Shared state with plain, unsynchronized fields.
 *
 * <p>Nothing here is volatile, atomic, or guarded by a lock. That is deliberate:
 * TSVD4J's field detector intercepts GETFIELD and PUTFIELD, so the racing accesses
 * must be on ordinary fields to be visible to it. A ConcurrentHashMap or an
 * AtomicInteger would be thread-safe by construction and any pair reported on it
 * would be a false positive -- which is exactly what happened on the four
 * FlakeSync benchmark subjects.
 */
public class SharedState {

    /** Written by a background thread, read by the test. Single writer in arm A. */
    private int value = 0;

    /** Read-modify-write by two threads in arm B, so updates can be lost. */
    private int counter = 0;

    /** Set after value is written; the test's completion signal in arm A. */
    private boolean ready = false;

    public void setValue(int v) {
        this.value = v;
    }

    public int getValue() {
        return this.value;
    }

    public void markReady() {
        this.ready = true;
    }

    public boolean isReady() {
        return this.ready;
    }

    /**
     * Unsynchronized read-modify-write. With two threads calling this, updates are
     * lost: both may read the same value before either writes back. No amount of
     * test-side ordering repairs this.
     */
    public void increment() {
        this.counter = this.counter + 1;
    }

    public int getCounter() {
        return this.counter;
    }
}
