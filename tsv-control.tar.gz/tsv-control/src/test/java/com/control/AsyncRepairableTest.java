package com.control;

import org.junit.Assert;
import org.junit.Test;

/**
 * Arm A -- POSITIVE CONTROL, repairable.
 *
 * <p>Both techniques' assumptions hold simultaneously:
 * <ul>
 *   <li>FlakeSync: the failure is an asynchronous wait. The test asserts before the
 *       producer thread has written, so a test-side barrier repairs it.</li>
 *   <li>TSVD4J: the racing accesses are plain field reads and writes on
 *       {@code SharedState.value}, so the field detector can see them.</li>
 * </ul>
 *
 * <p>Expected outcome of the discrimination experiment:
 * <pre>
 *   T1 (delayed, unpatched)  -> pair present, test fails
 *   T2 (delayed, patched)    -> pair absent,  test passes
 *   T1 \ T2 = the pair        -> verdict REPAIRABLE
 * </pre>
 *
 * <p>The pair should disappear under T2 because the barrier orders the test's read
 * after the producer's write, so the two accesses are no longer concurrent.
 */
public class AsyncRepairableTest {

    @Test
    public void testValueAfterAsyncWrite() throws Exception {
        SharedState state = new SharedState();

        Thread producer = Workers.producer(state, 60);
        producer.start();

        // Deliberately too short: the test may read before the producer writes.
        Thread.sleep(20);

        Assert.assertTrue("producer had not finished", state.isReady());
        Assert.assertEquals(42, state.getValue());

        producer.join();
    }
}
