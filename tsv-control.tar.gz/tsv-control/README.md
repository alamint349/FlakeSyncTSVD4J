# tsv-control — a positive control for the FlakeSync/TSVD4J integration

Two tests with the **same asynchronous-wait shape**, differing only in whether a
test-side barrier can repair the underlying bug. This is the setting in which both
techniques' assumptions hold, so it tests whether the integrated pipeline can
succeed at all.

Why two arms: one subject can only show the pipeline *runs*. Showing that it
*discriminates* requires a case it should call repairable and a case it should call
a genuine bug, with ground truth known by construction.

## Design

Both arms race on **plain `int` fields** in `SharedState` — no `volatile`, no
atomics, no concurrent collections. This is deliberate. On all four FlakeSync
benchmark subjects the only pairs TSVD4J reported were on `DoubleAdder` and a
`ConcurrentHashMap`, both thread-safe by construction and therefore false positives.
For the field detector to see a real conflict, the shared state must be an ordinary
field.

### Arm A — `AsyncRepairableTest#testValueAfterAsyncWrite`

One producer thread writes `value` after a delay; the test sleeps too briefly and
asserts. Single writer, so no update is lost — ordering the test after the write is
a genuine repair.

| Condition | Expected pairs | Expected outcome |
|---|---|---|
| T0 (no delay, unpatched) | possibly present | usually passes |
| T1 (delayed, unpatched) | **present** | fails |
| T2 (delayed, patched) | **absent** | passes |

`T1 \ T2` = the pair → verdict **REPAIRABLE**.

### Arm B — `AsyncGenuineRaceTest#testCounterAfterConcurrentIncrements`

Two threads do unsynchronized read-modify-write on `counter`. The test has the same
wait-then-assert shape, so FlakeSync engages, but the lost updates happen *between
the two workers*. A test-side barrier cannot recover them.

| Condition | Expected pairs | Expected outcome |
|---|---|---|
| T1 (delayed, unpatched) | **present** | fails |
| T2 (delayed, patched) | **present** | still fails |

`T1 ∩ T2` = the pair → verdict **GENUINE_BUG**.

## The three outcomes to distinguish

Your advisor asked for these to be separated explicitly. The instrumentation already
records what is needed:

| Outcome | Evidence | Seen on |
|---|---|---|
| **No pair exists** | whole-program run reports 0 pairs | mercury; rxjava2 `Transformers` |
| **Pair exists outside the region** | pair reported, `endpointsInRegion = 0` | rxjava2 `testCache` |
| **Pair exists but is unrelated to the failure** | identical pair set in T0 (passing) and T1 (failing) | rxjava2 `testCache` |
| *(fourth, sought here)* **Pair exists, in region, and causally related** | pair present in T1, absent in T2, `endpointsInRegion = 2` | target for arm A |

Note that rxjava2 `testCache` falls in **two** categories at once — outside the
region *and* unrelated to the failure. They are independent properties and should be
reported as separate columns, not one verdict.

## Running it

```bash
mvn clean install

# sanity: does each arm behave as designed, uninstrumented?
for i in $(seq 1 20); do
  mvn -q test -Dtest=AsyncRepairableTest 2>&1 | grep -c "BUILD FAILURE"
done
```

Arm A should fail intermittently. Arm B should fail most of the time. If arm A
always passes, lower the producer delay or raise the test's sleep gap; if it always
fails, do the reverse. Record whatever you settle on.

Then the FlakeSync pipeline, per arm, clearing the cache before each stage:

```bash
P=edu.utexas.ece:flakesync-maven-plugin:1.0-SNAPSHOT
T=com.control.AsyncRepairableTest#testValueAfterAsyncWrite

for g in concurrentfind delaylocs deltadebug critsearch barrierpointsearch patch; do
  rm -rf .flakesync/clean_* .flakesync/fail_*
  mvn $P:$g -Dflakesync.testName=$T -Djacoco.skip=true 2>&1 | tail -3
done
```

Then T0/T1/T2 via `run_conditions.sh`, and:

```bash
python3 tools/aggregate_tsv.py results/control-A --structure --classify T1 T2
```

## What each result would mean

- **Arm A gives REPAIRABLE and arm B gives GENUINE_BUG** — the integrated pipeline
  works when both techniques' assumptions hold. The benchmark failures are about the
  evaluation set, not the method. This is the outcome that would refute the
  fundamental-mismatch reading.
- **Arm A works, arm B does not** — the discriminator has one-sided validity; worth
  reporting as a partial result.
- **Neither arm works** — the limitation is in the tooling or the technique
  combination, and the four-subject result generalizes. This would substantiate the
  negative result rather than merely suggesting it.

Whichever occurs, this subject makes the claim testable, which is what the four
benchmark subjects could not do.
