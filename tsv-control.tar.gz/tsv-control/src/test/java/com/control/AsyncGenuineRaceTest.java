package com.control;

import org.junit.Assert;
import org.junit.Test;

/**
 * Arm B -- NEGATIVE CONTROL, not repairable by a barrier.
 *
 * <p>The test has the same asynchronous-wait shape as arm A -- it waits for
 * background work and then asserts -- so FlakeSync's pipeline engages. But the bug
 * is a lost-update race <em>between the two workers</em>, not between a worker and
 * the test. Ordering the test after both workers finish does not recover the lost
 * increments.
 *
 * <p>Expected outcome of the discrimination experiment:
 * <pre>
 *   T1 (delayed, unpatched)  -> pair present, test fails
 *   T2 (delayed, patched)    -> pair present, test still fails
 *   T1 &amp; T2 = the pair        -> verdict GENUINE_BUG
 * </pre>
 *
 * <p>Together with arm A this is the discriminator: the same tool, the same test
 * shape, and opposite verdicts driven only by whether the barrier removes the
 * conflicting accesses.
 */
public class AsyncGenuineRaceTest {

    private static final int ITERATIONS = 20000;

    @Test
    public void testCounterAfterConcurrentIncrements() throws Exception {
        SharedState state = new SharedState();

        Thread one = Workers.incrementer(state, ITERATIONS, "inc-1");
        Thread two = Workers.incrementer(state, ITERATIONS, "inc-2");

        one.start();
        two.start();

        // Same shape as arm A: wait, then assert.
        Thread.sleep(20);

        one.join();
        two.join();

        Assert.assertEquals(2 * ITERATIONS, state.getCounter());
    }
}
